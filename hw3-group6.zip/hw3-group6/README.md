# 16-662_HW_3_Discrete_Planners
Exploring the use of discrete planners for two different configuration spaces. Implement a Breadth-First Search, a Depth-First Search and an A-Star Search.
